fixup - Music directory fixer
=============================

.. {{{cog
.. cog.out(cog_pluginHelp("fixup"))
.. }}}
.. {{{end}}}
