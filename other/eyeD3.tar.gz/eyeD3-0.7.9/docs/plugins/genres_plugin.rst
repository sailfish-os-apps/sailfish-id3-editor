genres - ID3 Genre List
=======================

.. {{{cog
.. cog.out(cog_pluginHelp("genres"))
.. }}}
.. {{{end}}}

Example
-------

.. {{{cog cli_example("examples/cli_examples.sh", "GENRES_PLUGIN1", lang="bash") }}}
.. {{{end}}}
