stats - Music Collection Statistics
===================================

.. {{{cog
.. cog.out(cog_pluginHelp("stats"))
.. }}}
.. {{{end}}}
