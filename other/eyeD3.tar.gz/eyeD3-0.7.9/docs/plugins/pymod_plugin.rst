pymod - Use simple python modules as eyeD3 plugins
==================================================

.. {{{cog
.. cog.out(cog_pluginHelp("pymod"))
.. }}}
.. {{{end}}}

Example
-------

TODO
