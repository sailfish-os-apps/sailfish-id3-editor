xep-118 - Jabber (XMPP) Tune Format
===================================

.. {{{cog
.. cog.out(cog_pluginHelp("xep-118"))
.. }}}
.. {{{end}}}
