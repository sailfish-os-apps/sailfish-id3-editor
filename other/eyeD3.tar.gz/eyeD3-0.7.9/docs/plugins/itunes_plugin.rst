itunes-podcast - Convert files so iTunes recognizes them as podcasts
====================================================================

.. {{{cog
.. cog.out(cog_pluginHelp("itunes-podcast"))
.. }}}
.. {{{end}}}

Example
-------

.. {{{cog cli_example("examples/cli_examples.sh", "ITUNES_PODCAST_PLUGIN", lang="bash") }}}
.. {{{end}}}
