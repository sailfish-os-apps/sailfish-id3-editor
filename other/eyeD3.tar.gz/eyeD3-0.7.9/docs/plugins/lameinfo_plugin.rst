lameinfo (xing) - Lame (Xing) Header Information
================================================

.. {{{cog
.. cog.out(cog_pluginHelp("lameinfo"))
.. }}}
.. {{{end}}}

Example
-------

.. {{{cog cli_example("examples/cli_examples.sh", "LAME_PLUGIN", lang="bash") }}}
.. {{{end}}}
