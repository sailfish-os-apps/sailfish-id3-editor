mp3 Package
===========

:mod:`mp3` Package
------------------

.. automodule:: eyed3.mp3
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`headers` Module
---------------------

.. automodule:: eyed3.mp3.headers
    :members:
    :undoc-members:
    :show-inheritance:

