plugins Package
===============

:mod:`plugins` Package
----------------------

.. automodule:: eyed3.plugins
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`art` Module
-----------------

.. automodule:: eyed3.plugins.art
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`classic` Module
---------------------

.. automodule:: eyed3.plugins.classic
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`fixup` Module
-------------------

.. automodule:: eyed3.plugins.fixup
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`genres` Module
--------------------

.. automodule:: eyed3.plugins.genres
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`itunes` Module
--------------------

.. automodule:: eyed3.plugins.itunes
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`lameinfo` Module
----------------------

.. automodule:: eyed3.plugins.lameinfo
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`nfo` Module
-----------------

.. automodule:: eyed3.plugins.nfo
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`pymod` Module
-------------------

.. automodule:: eyed3.plugins.pymod
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`statistics` Module
------------------------

.. automodule:: eyed3.plugins.statistics
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`xep_118` Module
---------------------

.. automodule:: eyed3.plugins.xep_118
    :members:
    :undoc-members:
    :show-inheritance:

