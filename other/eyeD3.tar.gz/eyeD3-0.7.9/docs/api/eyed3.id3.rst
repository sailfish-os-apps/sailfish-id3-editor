id3 Package
===========

:mod:`id3` Package
------------------

.. automodule:: eyed3.id3
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`apple` Module
-------------------

.. automodule:: eyed3.id3.apple
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`frames` Module
--------------------

.. automodule:: eyed3.id3.frames
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`headers` Module
---------------------

.. automodule:: eyed3.id3.headers
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tag` Module
-----------------

.. automodule:: eyed3.id3.tag
    :members:
    :undoc-members:
    :show-inheritance:

